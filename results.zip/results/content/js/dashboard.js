/*
   Licensed to the Apache Software Foundation (ASF) under one or more
   contributor license agreements.  See the NOTICE file distributed with
   this work for additional information regarding copyright ownership.
   The ASF licenses this file to You under the Apache License, Version 2.0
   (the "License"); you may not use this file except in compliance with
   the License.  You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/
var showControllersOnly = false;
var seriesFilter = "";
var filtersOnlySampleSeries = true;

/*
 * Add header in statistics table to group metrics by category
 * format
 *
 */
function summaryTableHeader(header) {
    var newRow = header.insertRow(-1);
    newRow.className = "tablesorter-no-sort";
    var cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Requests";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 3;
    cell.innerHTML = "Executions";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 7;
    cell.innerHTML = "Response Times (ms)";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Throughput";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 2;
    cell.innerHTML = "Network (KB/sec)";
    newRow.appendChild(cell);
}

/*
 * Populates the table identified by id parameter with the specified data and
 * format
 *
 */
function createTable(table, info, formatter, defaultSorts, seriesIndex, headerCreator) {
    var tableRef = table[0];

    // Create header and populate it with data.titles array
    var header = tableRef.createTHead();

    // Call callback is available
    if(headerCreator) {
        headerCreator(header);
    }

    var newRow = header.insertRow(-1);
    for (var index = 0; index < info.titles.length; index++) {
        var cell = document.createElement('th');
        cell.innerHTML = info.titles[index];
        newRow.appendChild(cell);
    }

    var tBody;

    // Create overall body if defined
    if(info.overall){
        tBody = document.createElement('tbody');
        tBody.className = "tablesorter-no-sort";
        tableRef.appendChild(tBody);
        var newRow = tBody.insertRow(-1);
        var data = info.overall.data;
        for(var index=0;index < data.length; index++){
            var cell = newRow.insertCell(-1);
            cell.innerHTML = formatter ? formatter(index, data[index]): data[index];
        }
    }

    // Create regular body
    tBody = document.createElement('tbody');
    tableRef.appendChild(tBody);

    var regexp;
    if(seriesFilter) {
        regexp = new RegExp(seriesFilter, 'i');
    }
    // Populate body with data.items array
    for(var index=0; index < info.items.length; index++){
        var item = info.items[index];
        if((!regexp || filtersOnlySampleSeries && !info.supportsControllersDiscrimination || regexp.test(item.data[seriesIndex]))
                &&
                (!showControllersOnly || !info.supportsControllersDiscrimination || item.isController)){
            if(item.data.length > 0) {
                var newRow = tBody.insertRow(-1);
                for(var col=0; col < item.data.length; col++){
                    var cell = newRow.insertCell(-1);
                    cell.innerHTML = formatter ? formatter(col, item.data[col]) : item.data[col];
                }
            }
        }
    }

    // Add support of columns sort
    table.tablesorter({sortList : defaultSorts});
}

$(document).ready(function() {

    // Customize table sorter default options
    $.extend( $.tablesorter.defaults, {
        theme: 'blue',
        cssInfoBlock: "tablesorter-no-sort",
        widthFixed: true,
        widgets: ['zebra']
    });

    var data = {"OkPercent": 100.0, "KoPercent": 0.0};
    var dataset = [
        {
            "label" : "FAIL",
            "data" : data.KoPercent,
            "color" : "#FF6347"
        },
        {
            "label" : "PASS",
            "data" : data.OkPercent,
            "color" : "#9ACD32"
        }];
    $.plot($("#flot-requests-summary"), dataset, {
        series : {
            pie : {
                show : true,
                radius : 1,
                label : {
                    show : true,
                    radius : 3 / 4,
                    formatter : function(label, series) {
                        return '<div style="font-size:8pt;text-align:center;padding:2px;color:white;">'
                            + label
                            + '<br/>'
                            + Math.round10(series.percent, -2)
                            + '%</div>';
                    },
                    background : {
                        opacity : 0.5,
                        color : '#000'
                    }
                }
            }
        },
        legend : {
            show : true
        }
    });

    // Creates APDEX table
    createTable($("#apdexTable"), {"supportsControllersDiscrimination": true, "overall": {"data": [0.6158536585365854, 500, 1500, "Total"], "isController": false}, "titles": ["Apdex", "T (Toleration threshold)", "F (Frustration threshold)", "Label"], "items": [{"data": [1.0, 500, 1500, "https://www.webstaurantstore.com/outlet.html?category=26671"], "isController": false}, {"data": [1.0, 500, 1500, "https://www.webstaurantstore.com/outlet.html?category=2687"], "isController": false}, {"data": [1.0, 500, 1500, "https://www.webstaurantstore.com/outlet/360HFF12HC/65475.html"], "isController": false}, {"data": [1.0, 500, 1500, "https://www.webstaurantstore.com/outlet/91547055/65477.html"], "isController": false}, {"data": [1.0, 500, 1500, "https://www.webstaurantstore.com/outlet/584MULTI548H/63097.html"], "isController": false}, {"data": [1.0, 500, 1500, "https://www.webstaurantstore.com/outlet.html?category=4147"], "isController": false}, {"data": [1.0, 500, 1500, "https://www.webstaurantstore.com/outlet/348PSM23MTR/65111.html"], "isController": false}, {"data": [1.0, 500, 1500, "https://www.webstaurantstore.com/outlet/89717532184V/64825.html"], "isController": false}, {"data": [0.037037037037037035, 500, 1500, "Test"], "isController": true}, {"data": [0.5, 500, 1500, "https://www.webstaurantstore.com/outlet.html?category=13765"], "isController": false}, {"data": [0.5, 500, 1500, "https://www.webstaurantstore.com/outlet.html?category=13249"], "isController": false}, {"data": [1.0, 500, 1500, "https://www.webstaurantstore.com/outlet/4806110/61927.html"], "isController": false}, {"data": [1.0, 500, 1500, "https://www.webstaurantstore.com/outlet.html?category=13283"], "isController": false}, {"data": [1.0, 500, 1500, "https://www.webstaurantstore.com/outlet/495NOWFU3FDV/65791.html"], "isController": false}, {"data": [1.0, 500, 1500, "https://www.webstaurantstore.com/outlet/690FGSR14PLSS/65819.html"], "isController": false}, {"data": [0.5, 500, 1500, "https://www.webstaurantstore.com/outlet.html?category=47649"], "isController": false}, {"data": [1.0, 500, 1500, "https://www.webstaurantstore.com/outlet/991CDA64GYPL/65163.html"], "isController": false}, {"data": [1.0, 500, 1500, "https://www.webstaurantstore.com/outlet.html?category=48573"], "isController": false}, {"data": [1.0, 500, 1500, "https://www.webstaurantstore.com/outlet/575SHT4D/63685.html"], "isController": false}, {"data": [1.0, 500, 1500, "https://www.webstaurantstore.com/outlet/215EPPEL5/65903.html"], "isController": false}, {"data": [1.0, 500, 1500, "https://www.webstaurantstore.com/outlet/546MGSR2416/65627.html"], "isController": false}, {"data": [1.0, 500, 1500, "https://www.webstaurantstore.com/outlet/178CBE84HC/65937.html"], "isController": false}, {"data": [1.0, 500, 1500, "https://www.webstaurantstore.com/outlet/890TDD3HC/65629.html"], "isController": false}, {"data": [0.75, 500, 1500, "https://www.webstaurantstore.com/outlet/109PR103WT/64577.html"], "isController": false}, {"data": [0.5, 500, 1500, "https://www.webstaurantstore.com/outlet/890TDD2HC/65317.html"], "isController": false}, {"data": [0.48214285714285715, 500, 1500, "https://www.webstaurantstore.com/outlet-1"], "isController": false}, {"data": [1.0, 500, 1500, "https://www.webstaurantstore.com/outlet.html?category=3513"], "isController": false}, {"data": [1.0, 500, 1500, "https://www.webstaurantstore.com/outlet/178SSWD2R/65527.html"], "isController": false}, {"data": [1.0, 500, 1500, "https://www.webstaurantstore.com/outlet/305GUF27PD/65523.html"], "isController": false}, {"data": [1.0, 500, 1500, "https://www.webstaurantstore.com/outlet.html?category=65583"], "isController": false}, {"data": [1.0, 500, 1500, "https://www.webstaurantstore.com/outlet.html?category=42385"], "isController": false}, {"data": [0.9642857142857143, 500, 1500, "https://www.webstaurantstore.com/outlet-0"], "isController": false}, {"data": [0.5, 500, 1500, "https://www.webstaurantstore.com/outlet.html?category=48565"], "isController": false}, {"data": [1.0, 500, 1500, "https://www.webstaurantstore.com/outlet.html?category=13665"], "isController": false}, {"data": [1.0, 500, 1500, "https://www.webstaurantstore.com/outlet.html?category=57769"], "isController": false}, {"data": [1.0, 500, 1500, "https://www.webstaurantstore.com/outlet/520KB310SSWM/65583.html"], "isController": false}, {"data": [1.0, 500, 1500, "https://www.webstaurantstore.com/outlet.html?category=13463"], "isController": false}, {"data": [0.5, 500, 1500, "https://www.webstaurantstore.com/outlet.html?category=13387"], "isController": false}, {"data": [0.75, 500, 1500, "https://www.webstaurantstore.com/outlet.html?category=13581"], "isController": false}, {"data": [1.0, 500, 1500, "https://www.webstaurantstore.com/outlet.html?category=47665"], "isController": false}, {"data": [1.0, 500, 1500, "https://www.webstaurantstore.com/outlet/413C15E/64277.html"], "isController": false}, {"data": [0.5, 500, 1500, "https://www.webstaurantstore.com/outlet/415C80BAJADA/65741.html"], "isController": false}, {"data": [1.0, 500, 1500, "https://www.webstaurantstore.com/outlet.html?category=24767"], "isController": false}, {"data": [1.0, 500, 1500, "https://www.webstaurantstore.com/outlet.html?category=65513"], "isController": false}, {"data": [1.0, 500, 1500, "https://www.webstaurantstore.com/outlet/224BCD48SW/65773.html"], "isController": false}, {"data": [0.5, 500, 1500, "https://www.webstaurantstore.com/outlet.html?category=13949"], "isController": false}, {"data": [1.0, 500, 1500, "https://www.webstaurantstore.com/outlet/92268129/65165.html"], "isController": false}, {"data": [1.0, 500, 1500, "https://www.webstaurantstore.com/outlet/185DP93HC/65539.html"], "isController": false}, {"data": [1.0, 500, 1500, "https://www.webstaurantstore.com/outlet/189BVAC28HC/65581.html"], "isController": false}, {"data": [0.4642857142857143, 500, 1500, "https://www.webstaurantstore.com/outlet"], "isController": false}]}, function(index, item){
        switch(index){
            case 0:
                item = item.toFixed(3);
                break;
            case 1:
            case 2:
                item = formatDuration(item);
                break;
        }
        return item;
    }, [[0, 0]], 3);

    // Create statistics table
    createTable($("#statisticsTable"), {"supportsControllersDiscrimination": true, "overall": {"data": ["Total", 137, 0, 0.0, 639.839416058394, 101, 2212, 531.0, 1131.8, 1250.6999999999996, 2172.8600000000006, 0.15198883492237475, 116.46489432338343, 0.13863694166291318], "isController": false}, "titles": ["Label", "#Samples", "FAIL", "Error %", "Average", "Min", "Max", "Median", "90th pct", "95th pct", "99th pct", "Transactions/s", "Received", "Sent"], "items": [{"data": ["https://www.webstaurantstore.com/outlet.html?category=26671", 1, 0, 0.0, 225.0, 225, 225, 225.0, 225.0, 225.0, 225.0, 4.444444444444445, 724.3923611111111, 3.7934027777777777], "isController": false}, {"data": ["https://www.webstaurantstore.com/outlet.html?category=2687", 1, 0, 0.0, 233.0, 233, 233, 233.0, 233.0, 233.0, 233.0, 4.291845493562231, 697.9571821351931, 3.6589659334763946], "isController": false}, {"data": ["https://www.webstaurantstore.com/outlet/360HFF12HC/65475.html", 1, 0, 0.0, 315.0, 315, 315, 315.0, 315.0, 315.0, 315.0, 3.1746031746031744, 789.710441468254, 2.7157738095238093], "isController": false}, {"data": ["https://www.webstaurantstore.com/outlet/91547055/65477.html", 1, 0, 0.0, 404.0, 404, 404, 404.0, 404.0, 404.0, 404.0, 2.4752475247524752, 510.47387453589107, 2.1126624381188117], "isController": false}, {"data": ["https://www.webstaurantstore.com/outlet/584MULTI548H/63097.html", 1, 0, 0.0, 477.0, 477, 477, 477.0, 477.0, 477.0, 477.0, 2.0964360587002098, 452.53537735849056, 1.7975301362683438], "isController": false}, {"data": ["https://www.webstaurantstore.com/outlet.html?category=4147", 1, 0, 0.0, 389.0, 389, 389, 389.0, 389.0, 389.0, 389.0, 2.5706940874035986, 1957.2320854755783, 2.191617127249357], "isController": false}, {"data": ["https://www.webstaurantstore.com/outlet/348PSM23MTR/65111.html", 1, 0, 0.0, 359.0, 359, 359, 359.0, 359.0, 359.0, 359.0, 2.785515320334262, 501.86607764623955, 2.3856415389972145], "isController": false}, {"data": ["https://www.webstaurantstore.com/outlet/89717532184V/64825.html", 1, 0, 0.0, 249.0, 249, 249, 249.0, 249.0, 249.0, 249.0, 4.016064257028112, 971.8287211345381, 3.443461345381526], "isController": false}, {"data": ["Test", 27, 0, 0.0, 1968.148148148148, 1176, 3457, 1873.0, 2511.3999999999996, 3236.199999999999, 3457.0, 0.032601017876224804, 73.53437270774093, 0.10106574953664293], "isController": true}, {"data": ["https://www.webstaurantstore.com/outlet.html?category=13765", 2, 0, 0.0, 543.5, 531, 556, 543.5, 556.0, 556.0, 556.0, 0.20374898125509372, 180.40997319427464, 0.1739029390790546], "isController": false}, {"data": ["https://www.webstaurantstore.com/outlet.html?category=13249", 1, 0, 0.0, 510.0, 510, 510, 510.0, 510.0, 510.0, 510.0, 1.9607843137254901, 1348.6883425245098, 1.6735600490196079], "isController": false}, {"data": ["https://www.webstaurantstore.com/outlet/4806110/61927.html", 1, 0, 0.0, 452.0, 452, 452, 452.0, 452.0, 452.0, 452.0, 2.2123893805309733, 460.29798119469024, 1.8861483683628317], "isController": false}, {"data": ["https://www.webstaurantstore.com/outlet.html?category=13283", 1, 0, 0.0, 285.0, 285, 285, 285.0, 285.0, 285.0, 285.0, 3.5087719298245617, 964.7135416666667, 2.994791666666667], "isController": false}, {"data": ["https://www.webstaurantstore.com/outlet/495NOWFU3FDV/65791.html", 1, 0, 0.0, 311.0, 311, 311, 311.0, 311.0, 311.0, 311.0, 3.215434083601286, 877.3707546221865, 2.7569835209003215], "isController": false}, {"data": ["https://www.webstaurantstore.com/outlet/690FGSR14PLSS/65819.html", 1, 0, 0.0, 302.0, 302, 302, 302.0, 302.0, 302.0, 302.0, 3.3112582781456954, 876.3678342301325, 2.8423789321192054], "isController": false}, {"data": ["https://www.webstaurantstore.com/outlet.html?category=47649", 1, 0, 0.0, 698.0, 698, 698, 698.0, 698.0, 698.0, 698.0, 1.4326647564469914, 685.5090996597422, 1.2228017550143266], "isController": false}, {"data": ["https://www.webstaurantstore.com/outlet/991CDA64GYPL/65163.html", 1, 0, 0.0, 380.0, 380, 380, 380.0, 380.0, 380.0, 380.0, 2.631578947368421, 607.3036595394736, 2.256373355263158], "isController": false}, {"data": ["https://www.webstaurantstore.com/outlet.html?category=48573", 1, 0, 0.0, 301.0, 301, 301, 301.0, 301.0, 301.0, 301.0, 3.3222591362126246, 1021.9191237541529, 2.8356000830564785], "isController": false}, {"data": ["https://www.webstaurantstore.com/outlet/575SHT4D/63685.html", 1, 0, 0.0, 405.0, 405, 405, 405.0, 405.0, 405.0, 405.0, 2.4691358024691357, 603.6675347222222, 2.107445987654321], "isController": false}, {"data": ["https://www.webstaurantstore.com/outlet/215EPPEL5/65903.html", 1, 0, 0.0, 298.0, 298, 298, 298.0, 298.0, 298.0, 298.0, 3.3557046979865772, 1192.1042627936242, 2.8674234479865772], "isController": false}, {"data": ["https://www.webstaurantstore.com/outlet/546MGSR2416/65627.html", 1, 0, 0.0, 249.0, 249, 249, 249.0, 249.0, 249.0, 249.0, 4.016064257028112, 763.0482868975904, 3.439539407630522], "isController": false}, {"data": ["https://www.webstaurantstore.com/outlet/178CBE84HC/65937.html", 1, 0, 0.0, 371.0, 371, 371, 371.0, 371.0, 371.0, 371.0, 2.6954177897574128, 676.9315405997305, 2.3058456873315363], "isController": false}, {"data": ["https://www.webstaurantstore.com/outlet/890TDD3HC/65629.html", 1, 0, 0.0, 403.0, 403, 403, 403.0, 403.0, 403.0, 403.0, 2.4813895781637716, 665.4437422456575, 2.1203280086848633], "isController": false}, {"data": ["https://www.webstaurantstore.com/outlet/109PR103WT/64577.html", 2, 0, 0.0, 502.0, 397, 607, 502.0, 607.0, 607.0, 607.0, 0.0028073051695121044, 1.0392621805462174, 0.002401561844231058], "isController": false}, {"data": ["https://www.webstaurantstore.com/outlet/890TDD2HC/65317.html", 1, 0, 0.0, 619.0, 619, 619, 619.0, 619.0, 619.0, 619.0, 1.6155088852988693, 432.4862429321486, 1.3804397213247173], "isController": false}, {"data": ["https://www.webstaurantstore.com/outlet-1", 28, 0, 0.0, 951.5714285714284, 726, 2109, 880.0, 1115.8000000000004, 1758.4499999999978, 2109.0, 0.03109141987852138, 47.230284968825295, 0.02586903294580099], "isController": false}, {"data": ["https://www.webstaurantstore.com/outlet.html?category=3513", 1, 0, 0.0, 314.0, 314, 314, 314.0, 314.0, 314.0, 314.0, 3.1847133757961785, 519.3726363455414, 2.715092555732484], "isController": false}, {"data": ["https://www.webstaurantstore.com/outlet/178SSWD2R/65527.html", 1, 0, 0.0, 285.0, 285, 285, 285.0, 285.0, 285.0, 285.0, 3.5087719298245617, 1003.1901041666667, 2.998218201754386], "isController": false}, {"data": ["https://www.webstaurantstore.com/outlet/305GUF27PD/65523.html", 1, 0, 0.0, 466.0, 466, 466, 466.0, 466.0, 466.0, 466.0, 2.1459227467811157, 442.40796003218884, 1.8357698497854076], "isController": false}, {"data": ["https://www.webstaurantstore.com/outlet.html?category=65583", 1, 0, 0.0, 383.0, 383, 383, 383.0, 383.0, 383.0, 383.0, 2.6109660574412534, 699.2926933746736, 2.228500326370757], "isController": false}, {"data": ["https://www.webstaurantstore.com/outlet.html?category=42385", 1, 0, 0.0, 463.0, 463, 463, 463.0, 463.0, 463.0, 463.0, 2.1598272138228944, 1124.040311150108, 1.843446274298056], "isController": false}, {"data": ["https://www.webstaurantstore.com/outlet-0", 28, 0, 0.0, 202.2142857142857, 101, 803, 179.0, 418.4000000000002, 684.1999999999992, 803.0, 0.03113629691572739, 0.027669951360656173, 0.01839595667384284], "isController": false}, {"data": ["https://www.webstaurantstore.com/outlet.html?category=48565", 1, 0, 0.0, 673.0, 673, 673, 673.0, 673.0, 673.0, 673.0, 1.4858841010401187, 240.82060271173847, 1.2682252971768202], "isController": false}, {"data": ["https://www.webstaurantstore.com/outlet.html?category=13665", 1, 0, 0.0, 254.0, 254, 254, 254.0, 254.0, 254.0, 254.0, 3.937007874015748, 791.011780265748, 3.3602977362204722], "isController": false}, {"data": ["https://www.webstaurantstore.com/outlet.html?category=57769", 1, 0, 0.0, 339.0, 339, 339, 339.0, 339.0, 339.0, 339.0, 2.949852507374631, 904.6656065634218, 2.5177452064896753], "isController": false}, {"data": ["https://www.webstaurantstore.com/outlet/520KB310SSWM/65583.html", 1, 0, 0.0, 338.0, 338, 338, 338.0, 338.0, 338.0, 338.0, 2.9585798816568047, 738.7926451553254, 2.5367511094674553], "isController": false}, {"data": ["https://www.webstaurantstore.com/outlet.html?category=13463", 1, 0, 0.0, 353.0, 353, 353, 353.0, 353.0, 353.0, 353.0, 2.8328611898017, 730.3082949716714, 2.4178912889518416], "isController": false}, {"data": ["https://www.webstaurantstore.com/outlet.html?category=13387", 2, 0, 0.0, 766.5, 719, 814, 766.5, 814.0, 814.0, 814.0, 0.3500787677227376, 295.9712566186767, 0.2987976982321022], "isController": false}, {"data": ["https://www.webstaurantstore.com/outlet.html?category=13581", 2, 0, 0.0, 803.0, 431, 1175, 803.0, 1175.0, 1175.0, 1175.0, 0.36845983787767134, 292.64760702606856, 0.3144862288135593], "isController": false}, {"data": ["https://www.webstaurantstore.com/outlet.html?category=47665", 1, 0, 0.0, 236.0, 236, 236, 236.0, 236.0, 236.0, 236.0, 4.237288135593221, 693.0407507944916, 3.6165916313559325], "isController": false}, {"data": ["https://www.webstaurantstore.com/outlet/413C15E/64277.html", 1, 0, 0.0, 353.0, 353, 353, 353.0, 353.0, 353.0, 353.0, 2.8328611898017, 614.6783153328612, 2.4151248229461757], "isController": false}, {"data": ["https://www.webstaurantstore.com/outlet/415C80BAJADA/65741.html", 1, 0, 0.0, 536.0, 536, 536, 536.0, 536.0, 536.0, 536.0, 1.8656716417910448, 487.3028655550373, 1.5996676772388059], "isController": false}, {"data": ["https://www.webstaurantstore.com/outlet.html?category=24767", 2, 0, 0.0, 369.5, 308, 431, 369.5, 431.0, 431.0, 431.0, 0.0028076598576235686, 1.0633902036536078, 0.0023963815581669913], "isController": false}, {"data": ["https://www.webstaurantstore.com/outlet.html?category=65513", 2, 0, 0.0, 362.5, 338, 387, 362.5, 387.0, 387.0, 387.0, 0.01634427582599884, 5.1075063895903305, 0.01395009479679979], "isController": false}, {"data": ["https://www.webstaurantstore.com/outlet/224BCD48SW/65773.html", 1, 0, 0.0, 494.0, 494, 494, 494.0, 494.0, 494.0, 494.0, 2.0242914979757085, 496.76587803643724, 1.731718117408907], "isController": false}, {"data": ["https://www.webstaurantstore.com/outlet.html?category=13949", 2, 0, 0.0, 676.0, 514, 838, 676.0, 838.0, 838.0, 838.0, 0.021084591380619043, 20.14016023301109, 0.017996028190098677], "isController": false}, {"data": ["https://www.webstaurantstore.com/outlet/92268129/65165.html", 1, 0, 0.0, 467.0, 467, 467, 467.0, 467.0, 467.0, 467.0, 2.1413276231263385, 466.34518870449676, 1.827656584582441], "isController": false}, {"data": ["https://www.webstaurantstore.com/outlet/185DP93HC/65539.html", 1, 0, 0.0, 395.0, 395, 395, 395.0, 395.0, 395.0, 395.0, 2.5316455696202533, 725.0939477848101, 2.1632713607594938], "isController": false}, {"data": ["https://www.webstaurantstore.com/outlet/189BVAC28HC/65581.html", 1, 0, 0.0, 368.0, 368, 368, 368.0, 368.0, 368.0, 368.0, 2.717391304347826, 771.1606233016305, 2.3272970448369565], "isController": false}, {"data": ["https://www.webstaurantstore.com/outlet", 28, 0, 0.0, 1155.5, 871, 2212, 1074.5, 1490.9000000000005, 2061.249999999999, 2212.0, 0.031063411516981703, 47.21534326941852, 0.04419862361351791], "isController": false}]}, function(index, item){
        switch(index){
            // Errors pct
            case 3:
                item = item.toFixed(2) + '%';
                break;
            // Mean
            case 4:
            // Mean
            case 7:
            // Median
            case 8:
            // Percentile 1
            case 9:
            // Percentile 2
            case 10:
            // Percentile 3
            case 11:
            // Throughput
            case 12:
            // Kbytes/s
            case 13:
            // Sent Kbytes/s
                item = item.toFixed(2);
                break;
        }
        return item;
    }, [[0, 0]], 0, summaryTableHeader);

    // Create error table
    createTable($("#errorsTable"), {"supportsControllersDiscrimination": false, "titles": ["Type of error", "Number of errors", "% in errors", "% in all samples"], "items": []}, function(index, item){
        switch(index){
            case 2:
            case 3:
                item = item.toFixed(2) + '%';
                break;
        }
        return item;
    }, [[1, 1]]);

        // Create top5 errors by sampler
    createTable($("#top5ErrorsBySamplerTable"), {"supportsControllersDiscrimination": false, "overall": {"data": ["Total", 137, 0, "", "", "", "", "", "", "", "", "", ""], "isController": false}, "titles": ["Sample", "#Samples", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors"], "items": [{"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}]}, function(index, item){
        return item;
    }, [[0, 0]], 0);

});
